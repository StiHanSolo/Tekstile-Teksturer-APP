export interface ChildProfile {
  id: string;
  anonymousId: string;
  age: number;
  preferences: TextilePreference[];
}

export interface TextilePreference {
  categoryId: string;
  rating: number;
  timestamp: number;
}

export interface TextileCategory {
  id: string;
  name: string;
  type: string;
  properties: string[];
  imageUrl?: string;
}

export interface InteractionRecord {
  id: string;
  childId: string;
  categoryId: string;
  timestamp: number;
  duration: number;
  reaction: 'positive' | 'neutral' | 'negative';
  notes?: string;
}