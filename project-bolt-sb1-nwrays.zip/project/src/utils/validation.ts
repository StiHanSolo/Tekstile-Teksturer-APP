import { InteractionRecord, ChildProfile } from '../types';

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export const validateInteraction = (interaction: Partial<InteractionRecord>): void => {
  if (!interaction.childId) {
    throw new ValidationError('Child ID is required');
  }

  if (!interaction.categoryId) {
    throw new ValidationError('Textile category is required');
  }

  if (typeof interaction.duration !== 'number' || interaction.duration < 0) {
    throw new ValidationError('Duration must be a positive number');
  }

  if (!['positive', 'neutral', 'negative'].includes(interaction.reaction || '')) {
    throw new ValidationError('Invalid reaction type');
  }
};

export const validateChildProfile = (profile: Partial<ChildProfile>): void => {
  if (!profile.anonymousId) {
    throw new ValidationError('Anonymous ID is required');
  }

  if (typeof profile.age !== 'number' || profile.age < 0 || profile.age > 18) {
    throw new ValidationError('Age must be between 0 and 18');
  }
};

type SanitizableData = Record<string, unknown>;

export const sanitizeData = <T extends SanitizableData>(data: T): T => {
  const sanitized = { ...data };
  
  for (const [key, value] of Object.entries(sanitized)) {
    if (typeof value === 'string') {
      sanitized[key] = value.trim() as unknown;
    }
  }

  return sanitized;
};