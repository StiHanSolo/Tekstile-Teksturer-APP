import { InteractionRecord } from '../types';

// Optimized data aggregation with memoization
const memoizedResults = new Map<string, any>();

export const analyzePreferences = (interactions: InteractionRecord[], childId: string) => {
  const cacheKey = `${childId}-${interactions.length}`;
  if (memoizedResults.has(cacheKey)) {
    return memoizedResults.get(cacheKey);
  }

  const childInteractions = interactions.filter(i => i.childId === childId);
  const results = childInteractions.reduce((acc, curr) => {
    if (!acc[curr.categoryId]) {
      acc[curr.categoryId] = {
        positive: 0,
        neutral: 0,
        negative: 0,
        totalDuration: 0,
        averageDuration: 0
      };
    }
    
    acc[curr.categoryId][curr.reaction]++;
    acc[curr.categoryId].totalDuration += curr.duration;
    acc[curr.categoryId].averageDuration = 
      acc[curr.categoryId].totalDuration / 
      (acc[curr.categoryId].positive + acc[curr.categoryId].neutral + acc[curr.categoryId].negative);
    
    return acc;
  }, {} as Record<string, {
    positive: number;
    neutral: number;
    negative: number;
    totalDuration: number;
    averageDuration: number;
  }>);

  memoizedResults.set(cacheKey, results);
  return results;
};

// Optimized trend analysis with batch processing
export const analyzeTrends = (interactions: InteractionRecord[], childId: string) => {
  const BATCH_SIZE = 50;
  const childInteractions = interactions
    .filter(i => i.childId === childId)
    .sort((a, b) => a.timestamp - b.timestamp);

  const batches = [];
  for (let i = 0; i < childInteractions.length; i += BATCH_SIZE) {
    batches.push(childInteractions.slice(i, i + BATCH_SIZE));
  }

  return batches.map(batch => {
    const batchStart = batch[0].timestamp;
    const batchEnd = batch[batch.length - 1].timestamp;
    
    return {
      period: {
        start: new Date(batchStart),
        end: new Date(batchEnd)
      },
      averageDuration: batch.reduce((sum, curr) => sum + curr.duration, 0) / batch.length,
      reactionDistribution: batch.reduce((acc, curr) => {
        acc[curr.reaction]++;
        return acc;
      }, { positive: 0, neutral: 0, negative: 0 })
    };
  });
};