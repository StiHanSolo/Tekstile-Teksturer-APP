import { encryptData, decryptData } from './encryption';

export const StorageKeys = {
  CHILDREN: 'textile-tracker-children',
  INTERACTIONS: 'textile-tracker-interactions',
  CATEGORIES: 'textile-tracker-categories',
};

export const saveToStorage = <T>(key: string, data: T): void => {
  const stringData = JSON.stringify(data);
  const encryptedData = encryptData(stringData);
  localStorage.setItem(key, encryptedData);
};

export const getFromStorage = <T>(key: string): T | null => {
  const encryptedData = localStorage.getItem(key);
  if (!encryptedData) return null;
  const decryptedData = decryptData(encryptedData);
  return JSON.parse(decryptedData) as T;
};