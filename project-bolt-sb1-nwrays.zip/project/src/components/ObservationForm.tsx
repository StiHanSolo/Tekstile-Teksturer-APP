import { useState } from 'react';
import {
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Typography,
  Box,
  Chip,
  Zoom,
  Tooltip,
  Paper,
  useTheme,
} from '@mui/material';
import { Add as AddIcon, TouchApp, Timer, Mood as MoodIcon } from '@mui/icons-material';
import { saveToStorage, getFromStorage, StorageKeys } from '../utils/storage';
import { InteractionRecord } from '../types';
import { v4 as uuidv4 } from 'uuid';

const textileCategories = [
  { id: 'rough', label: 'Rough', icon: '🧶', color: '#f44336' },
  { id: 'smooth', label: 'Smooth', icon: '🎐', color: '#2196f3' },
  { id: 'soft', label: 'Soft', icon: '🧸', color: '#4caf50' },
  { id: 'scratchy', label: 'Scratchy', icon: '🌵', color: '#ff9800' },
  { id: 'fluffy', label: 'Fluffy', icon: '☁️', color: '#9c27b0' },
  { id: 'silky', label: 'Silky', icon: '🎀', color: '#e91e63' },
];

const reactionEmojis = {
  positive: { icon: '😊', label: 'Positive', color: '#4caf50' },
  neutral: { icon: '😐', label: 'Neutral', color: '#ff9800' },
  negative: { icon: '😕', label: 'Negative', color: '#f44336' },
};

const ObservationForm = () => {
  const theme = useTheme();
  const [formData, setFormData] = useState({
    childId: '',
    textileType: '',
    duration: '',
    reaction: 'neutral' as 'positive' | 'neutral' | 'negative',
    notes: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const interaction: InteractionRecord = {
      id: uuidv4(),
      childId: formData.childId,
      categoryId: formData.textileType,
      timestamp: Date.now(),
      duration: Number(formData.duration),
      reaction: formData.reaction,
      notes: formData.notes,
    };

    const existingData = getFromStorage<InteractionRecord[]>(StorageKeys.INTERACTIONS) || [];
    const updatedInteractions = [...existingData, interaction];
    saveToStorage(StorageKeys.INTERACTIONS, updatedInteractions);

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        childId: formData.childId,
        textileType: '',
        duration: '',
        reaction: 'neutral',
        notes: '',
      });
      setSelectedCategory(null);
    }, 1500);
  };

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Typography 
        variant="h6" 
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          mb: 3,
          color: theme.palette.primary.main,
          fontWeight: 600,
        }}
      >
        <TouchApp /> New Observation
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Anonymous Child ID"
            value={formData.childId}
            onChange={(e) => setFormData({ ...formData, childId: e.target.value })}
            required
            variant="outlined"
            className="form-field"
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 2,
                transition: 'all 0.2s ease-in-out',
                '&:hover, &.Mui-focused': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                },
              },
            }}
          />
        </Grid>

        <Grid item xs={12}>
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Textile Type</Typography>
            <Box 
              sx={{ 
                display: 'grid', 
                gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
                gap: 1,
              }}
            >
              {textileCategories.map((category) => (
                <Paper
                  key={category.id}
                  elevation={0}
                  onClick={() => {
                    setFormData({ ...formData, textileType: category.id });
                    setSelectedCategory(category.id);
                  }}
                  sx={{
                    p: 1.5,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    cursor: 'pointer',
                    border: '2px solid',
                    borderColor: selectedCategory === category.id ? category.color : 'transparent',
                    bgcolor: selectedCategory === category.id ? `${category.color}10` : 'background.paper',
                    transition: 'all 0.2s ease-in-out',
                    '&:hover': {
                      transform: 'translateY(-2px)',
                      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                      bgcolor: `${category.color}10`,
                    },
                  }}
                >
                  <span style={{ fontSize: '1.5rem' }}>{category.icon}</span>
                  <Typography>{category.label}</Typography>
                </Paper>
              ))}
            </Box>
          </Box>
        </Grid>

        <Grid item xs={12}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Timer sx={{ color: theme.palette.text.secondary }} />
            <TextField
              fullWidth
              label="Duration (seconds)"
              type="number"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
              required
              inputProps={{ min: 0 }}
              className="form-field"
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2,
                  transition: 'all 0.2s ease-in-out',
                  '&:hover, &.Mui-focused': {
                    transform: 'translateY(-2px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                  },
                },
              }}
            />
          </Box>
        </Grid>

        <Grid item xs={12}>
          <Typography 
            variant="subtitle2" 
            sx={{ 
              mb: 1,
              display: 'flex',
              alignItems: 'center',
              gap: 1,
            }}
          >
            <MoodIcon sx={{ fontSize: 20 }} /> Reaction
          </Typography>
          <Box 
            sx={{ 
              display: 'flex', 
              gap: 2,
              justifyContent: 'center',
              mb: 2,
            }}
          >
            {Object.entries(reactionEmojis).map(([key, { icon, label, color }]) => (
              <Tooltip key={key} title={label}>
                <Paper
                  elevation={0}
                  onClick={() => setFormData({ ...formData, reaction: key as any })}
                  sx={{
                    p: 2,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 80,
                    height: 80,
                    fontSize: '2rem',
                    border: '2px solid',
                    borderColor: formData.reaction === key ? color : 'transparent',
                    bgcolor: formData.reaction === key ? `${color}10` : 'background.paper',
                    transition: 'all 0.2s ease-in-out',
                    '&:hover': {
                      transform: 'scale(1.05)',
                      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                      bgcolor: `${color}10`,
                    },
                  }}
                >
                  {icon}
                </Paper>
              </Tooltip>
            ))}
          </Box>
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Notes (optional)"
            multiline
            rows={2}
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            className="form-field"
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 2,
                transition: 'all 0.2s ease-in-out',
                '&:hover, &.Mui-focused': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                },
              },
            }}
          />
        </Grid>

        <Grid item xs={12}>
          <Zoom in={!submitted}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              fullWidth
              disabled={!formData.textileType}
              startIcon={<AddIcon />}
              sx={{
                py: 1.5,
                borderRadius: 2,
                transition: 'all 0.2s ease-in-out',
                '&:not(:disabled):hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: theme.shadows[6],
                },
              }}
            >
              Save Observation
            </Button>
          </Zoom>
          <Zoom in={submitted}>
            <Box 
              sx={{ 
                textAlign: 'center',
                color: 'success.main',
                fontSize: '1.5rem',
                p: 2,
              }}
            >
              ✅ Saved Successfully!
            </Box>
          </Zoom>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ObservationForm;