import { useState, useEffect } from 'react';
import { Paper, Typography, Grid, Box, Fade, useTheme } from '@mui/material';
import ObservationForm from './ObservationForm';
import { PreferenceChart } from './PreferenceChart';
import { InteractionChart } from './InteractionChart';
import { PreferencesSummary } from './PreferencesSummary';
import { ExportData } from './ExportData';
import { LoadingSpinner } from './LoadingSpinner';
import { getFromStorage, StorageKeys } from '../utils/storage';
import { InteractionRecord } from '../types';

const Dashboard = () => {
  const [interactions, setInteractions] = useState<InteractionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const theme = useTheme();

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const storedInteractions = getFromStorage<InteractionRecord[]>(StorageKeys.INTERACTIONS) || [];
        setInteractions(storedInteractions);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <Box sx={{ py: 4 }}>
      <Fade in timeout={800}>
        <Typography 
          variant="h4" 
          component="h1" 
          gutterBottom
          sx={{
            textAlign: 'center',
            mb: 4,
            background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            color: 'transparent',
          }}
        >
          Textile Interaction Tracker
        </Typography>
      </Fade>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Fade in timeout={1000}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                height: '100%',
                background: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(10px)',
                transition: 'transform 0.2s ease-in-out',
                '&:hover': {
                  transform: 'translateY(-4px)',
                }
              }}
              className="hover-scale"
            >
              <ObservationForm />
            </Paper>
          </Fade>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Fade in timeout={1200}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                height: '100%',
                background: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(10px)',
              }}
              className="hover-scale"
            >
              <PreferenceChart />
            </Paper>
          </Fade>
        </Grid>

        <Grid item xs={12} md={6}>
          <Fade in timeout={1400}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                height: '100%',
                background: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(10px)',
              }}
              className="hover-scale"
            >
              <InteractionChart interactions={interactions} />
            </Paper>
          </Fade>
        </Grid>

        <Grid item xs={12} md={6}>
          <Fade in timeout={1600}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                height: '100%',
                background: 'rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(10px)',
              }}
              className="hover-scale"
            >
              <PreferencesSummary interactions={interactions} />
            </Paper>
          </Fade>
        </Grid>

        {interactions.length > 0 && (
          <Grid item xs={12}>
            <Fade in timeout={1800}>
              <Paper 
                elevation={0}
                sx={{ 
                  p: 3,
                  background: 'rgba(255, 255, 255, 0.8)',
                  backdropFilter: 'blur(10px)',
                }}
                className="hover-scale"
              >
                <Typography variant="h6" gutterBottom>
                  Export Data
                </Typography>
                <ExportData 
                  interactions={interactions}
                  childId={interactions[0].childId}
                />
              </Paper>
            </Fade>
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

export default Dashboard;