import React, { useState } from 'react';
import { Paper, TextField, Button, Typography, Box } from '@mui/material';
import { v4 as uuidv4 } from 'uuid';
import { ChildProfile as IChildProfile } from '../types';

interface ChildProfileProps {
  onSave: (profile: IChildProfile) => void;
}

export const ChildProfile: React.FC<ChildProfileProps> = ({ onSave }) => {
  const [age, setAge] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const profile: IChildProfile = {
      id: uuidv4(),
      anonymousId: uuidv4().slice(0, 8),
      age: parseInt(age),
      preferences: []
    };
    onSave(profile);
    setAge('');
  };

  return (
    <Paper elevation={3} sx={{ p: 3, maxWidth: 400, mx: 'auto', mt: 3 }}>
      <Typography variant="h6" gutterBottom>
        Create Child Profile
      </Typography>
      <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <TextField
          required
          type="number"
          label="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          inputProps={{ min: 0, max: 18 }}
        />
        <Button type="submit" variant="contained" color="primary">
          Create Profile
        </Button>
      </Box>
    </Paper>
  );
};