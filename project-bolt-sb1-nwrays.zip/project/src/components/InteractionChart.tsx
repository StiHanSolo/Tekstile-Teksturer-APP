import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Typography } from '@mui/material';
import { InteractionRecord } from '../types';

interface InteractionChartProps {
  interactions: InteractionRecord[];
}

export const InteractionChart: React.FC<InteractionChartProps> = ({ interactions }) => {
  const chartData = interactions.map(interaction => ({
    date: new Date(interaction.timestamp).toLocaleDateString(),
    duration: interaction.duration,
    reaction: interaction.reaction === 'positive' ? 1 : interaction.reaction === 'neutral' ? 0 : -1
  }));

  return (
    <>
      <Typography variant="h6" gutterBottom>
        Interaction History
      </Typography>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="duration" stroke="#8884d8" name="Duration (s)" />
          <Line type="monotone" dataKey="reaction" stroke="#82ca9d" name="Reaction" />
        </LineChart>
      </ResponsiveContainer>
    </>
  );
};