import { Typography, List, ListItem, Box, Stack, Paper, Fade, useTheme } from '@mui/material';
import { InteractionRecord } from '../types';

interface PreferencesSummaryProps {
  interactions: InteractionRecord[];
}

export const PreferencesSummary = ({ interactions }: PreferencesSummaryProps) => {
  const theme = useTheme();
  const preferences = interactions.reduce((acc, curr) => {
    if (!acc[curr.categoryId]) {
      acc[curr.categoryId] = { positive: 0, neutral: 0, negative: 0 };
    }
    acc[curr.categoryId][curr.reaction]++;
    return acc;
  }, {} as Record<string, { positive: number; neutral: number; negative: number }>);

  const textileIcons: Record<string, string> = {
    rough: '🧶',
    smooth: '🎐',
    soft: '🧸',
    scratchy: '🌵',
    fluffy: '☁️',
    silky: '🎀'
  };

  return (
    <Box>
      <Typography variant="h6" component="div" gutterBottom>
        Texture Preferences
      </Typography>
      <List sx={{ width: '100%' }}>
        {Object.entries(preferences).map(([category, reactions], index) => (
          <Fade in timeout={500 + index * 100} key={category}>
            <ListItem 
              component={Box} 
              sx={{ 
                mb: 2,
                p: 0,
                display: 'block',
              }}
            >
              <Paper
                elevation={0}
                sx={{ 
                  p: 2,
                  transition: 'all 0.2s ease-in-out',
                  '&:hover': {
                    transform: 'translateY(-2px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                    bgcolor: 'rgba(0,0,0,0.02)'
                  }
                }}
              >
                <Box 
                  sx={{ 
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    mb: 2
                  }}
                >
                  <span style={{ fontSize: '1.5rem' }}>
                    {textileIcons[category.toLowerCase()] || '📋'}
                  </span>
                  <Typography 
                    variant="subtitle1" 
                    component="div" 
                    sx={{ 
                      fontWeight: 500,
                      color: theme.palette.primary.main
                    }}
                  >
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </Typography>
                </Box>

                <Stack 
                  spacing={1} 
                  sx={{
                    '& > div': {
                      borderRadius: 1,
                      p: 1.5,
                      transition: 'all 0.2s ease-in-out',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      '&:hover': {
                        transform: 'scale(1.02)'
                      }
                    }
                  }}
                >
                  <Box sx={{ 
                    bgcolor: 'success.main', 
                    color: 'white',
                    opacity: 0.9,
                    boxShadow: `inset 0 0 0 1px ${theme.palette.success.dark}` 
                  }}>
                    <Typography component="div" variant="body2">
                      Positive
                    </Typography>
                    <Typography component="div" variant="body2" sx={{ fontWeight: 'bold' }}>
                      {reactions.positive}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ 
                    bgcolor: 'warning.main',
                    color: 'white',
                    opacity: 0.9,
                    boxShadow: `inset 0 0 0 1px ${theme.palette.warning.dark}`
                  }}>
                    <Typography component="div" variant="body2">
                      Neutral
                    </Typography>
                    <Typography component="div" variant="body2" sx={{ fontWeight: 'bold' }}>
                      {reactions.neutral}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ 
                    bgcolor: 'error.main',
                    color: 'white',
                    opacity: 0.9,
                    boxShadow: `inset 0 0 0 1px ${theme.palette.error.dark}`
                  }}>
                    <Typography component="div" variant="body2">
                      Negative
                    </Typography>
                    <Typography component="div" variant="body2" sx={{ fontWeight: 'bold' }}>
                      {reactions.negative}
                    </Typography>
                  </Box>
                </Stack>
              </Paper>
            </ListItem>
          </Fade>
        ))}
      </List>
    </Box>
  );
};