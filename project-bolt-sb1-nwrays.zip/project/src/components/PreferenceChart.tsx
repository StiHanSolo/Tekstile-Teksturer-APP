import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Typography, Box, CircularProgress } from '@mui/material';
import { useState, useEffect } from 'react';
import { getFromStorage, StorageKeys } from '../utils/storage';
import { InteractionRecord } from '../types';
import { analyzePreferences } from '../utils/analytics';

export const PreferenceChart = () => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const interactions = getFromStorage<InteractionRecord[]>(StorageKeys.INTERACTIONS) || [];
        
        if (interactions.length === 0) {
          setData([]);
          return;
        }

        const preferences = analyzePreferences(interactions, interactions[0].childId);
        const chartData = Object.entries(preferences).map(([category, stats]) => ({
          category,
          positive: stats.positive,
          negative: stats.negative,
          neutral: stats.neutral,
          avgDuration: Math.round(stats.averageDuration)
        }));

        setData(chartData);
      } catch (err) {
        setError('Failed to load preference data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Typography color="error" align="center">
        {error}
      </Typography>
    );
  }

  if (data.length === 0) {
    return (
      <Typography color="textSecondary" align="center">
        No preference data available yet
      </Typography>
    );
  }

  return (
    <Box sx={{ width: '100%', height: 400 }}>
      <Typography variant="h6" component="div" gutterBottom>
        Texture Preferences Overview
      </Typography>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="category" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="positive" name="Positive" fill="#4caf50" />
          <Bar dataKey="neutral" name="Neutral" fill="#ff9800" />
          <Bar dataKey="negative" name="Negative" fill="#f44336" />
          <Bar dataKey="avgDuration" name="Average Duration (s)" fill="#2196f3" />
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
};