import { Button, Stack, Snackbar, Alert } from '@mui/material';
import { useState } from 'react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { InteractionRecord } from '../types';

interface ExportDataProps {
  interactions: InteractionRecord[];
  childId: string;
}

export const ExportData: React.FC<ExportDataProps> = ({ interactions, childId }) => {
  const [notification, setNotification] = useState<{
    message: string;
    severity: 'success' | 'error';
  } | null>(null);

  const childInteractions = interactions.filter(i => i.childId === childId);

  const handleExport = async (format: 'csv' | 'pdf') => {
    try {
      if (format === 'csv') {
        await exportCSV();
      } else {
        await exportPDF();
      }
      setNotification({
        message: `Successfully exported data as ${format.toUpperCase()}`,
        severity: 'success'
      });
    } catch (error) {
      console.error('Export failed:', error);
      setNotification({
        message: `Failed to export data as ${format.toUpperCase()}`,
        severity: 'error'
      });
    }
  };

  const exportCSV = async () => {
    const headers = ['Date', 'Textile Type', 'Duration (s)', 'Reaction', 'Notes'];
    const rows = childInteractions.map(interaction => [
      new Date(interaction.timestamp).toLocaleDateString(),
      interaction.categoryId,
      interaction.duration.toString(),
      interaction.reaction,
      interaction.notes || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `textile-interactions-${childId}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const exportPDF = async () => {
    const doc = new jsPDF();
    const headers = ['Date', 'Textile', 'Duration', 'Reaction', 'Notes'];
    
    doc.setFontSize(16);
    doc.text('Textile Interaction Report', 20, 20);
    
    doc.setFontSize(12);
    doc.text(`Child ID: ${childId}`, 20, 30);
    doc.text(`Report Date: ${new Date().toLocaleDateString()}`, 20, 40);

    const tableData = childInteractions.map(interaction => [
      new Date(interaction.timestamp).toLocaleDateString(),
      interaction.categoryId,
      `${interaction.duration}s`,
      interaction.reaction,
      interaction.notes || ''
    ]);

    (doc as any).autoTable({
      head: [headers],
      body: tableData,
      startY: 50,
      margin: { top: 50 },
      styles: { fontSize: 10 },
      headStyles: { fillColor: [33, 150, 243] }
    });

    doc.save(`textile-interactions-${childId}.pdf`);
  };

  return (
    <>
      <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => handleExport('csv')}
          aria-label="Export as CSV"
        >
          Export CSV
        </Button>
        <Button
          variant="contained"
          color="secondary"
          onClick={() => handleExport('pdf')}
          aria-label="Export as PDF"
        >
          Export PDF
        </Button>
      </Stack>
      <Snackbar
        open={!!notification}
        autoHideDuration={6000}
        onClose={() => setNotification(null)}
      >
        <Alert 
          onClose={() => setNotification(null)} 
          severity={notification?.severity}
          sx={{ width: '100%' }}
        >
          {notification?.message}
        </Alert>
      </Snackbar>
    </>
  );
};