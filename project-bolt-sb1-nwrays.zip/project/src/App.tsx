import { Container, Box } from '@mui/material';
import Dashboard from './components/Dashboard';

const App = () => {
  return (
    <Container maxWidth="lg">
      <Box 
        sx={{ 
          my: 4,
          minHeight: '100vh',
          background: 'linear-gradient(135deg, rgba(255,255,255,0.8) 0%, rgba(240,242,245,0.8) 100%)',
          borderRadius: '16px',
          p: { xs: 2, md: 4 },
          backdropFilter: 'blur(10px)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
        }}
      >
        <Dashboard />
      </Box>
    </Container>
  );
};

export default App;